 0x03. Shell, init files, variables and expansions 
