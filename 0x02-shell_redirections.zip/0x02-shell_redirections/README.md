This project is about  Shell, I/O Redirections and filters
