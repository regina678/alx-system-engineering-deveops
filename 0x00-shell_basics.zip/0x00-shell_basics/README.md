a script that prints the absolute path name of the current working directory
