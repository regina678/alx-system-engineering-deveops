Networking basics 2
