0x01. Shell, permissions
