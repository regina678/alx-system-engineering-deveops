#!/usr/bin/env ruby
#simply search
puts ARGV[0].scan(/School/).join
